import React, { Component } from 'react';

const TodoListHeader = () => {
  return(
    <thead>
      <tr>
        <th>Task</th>
        <th>Action</th>
      </tr>
    </thead>
  )
};

export default TodoListHeader;
