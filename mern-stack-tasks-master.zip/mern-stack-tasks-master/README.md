# MERN STACK
this is a CRUD app example write with React, Node, Expres and Mongodb
