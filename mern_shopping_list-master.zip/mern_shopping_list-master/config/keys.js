module.exports = {
  mongoURI: 'mongodb://YOUR_MONGO_URI'
};
