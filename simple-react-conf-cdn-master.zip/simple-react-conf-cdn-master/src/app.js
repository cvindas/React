
// JSX - JAVASCRIPT XML
let template = <p>This is JXS from app.js!</p>;

let appRoot = document.getElementById('app');

ReactDOM.render(
    template,
    appRoot
);