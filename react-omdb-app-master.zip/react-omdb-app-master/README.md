## Screenshot
![](./screenshot.png)
## Requeriments
* [OMDB API KEY](http://www.omdbapi.com/)


