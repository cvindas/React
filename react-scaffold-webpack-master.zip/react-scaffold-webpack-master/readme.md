## React Fazt Scaffold
this is a scaffold from scratch with React and Webpack

## Commands
- to execute on development: `npm run dev`
- to execute on production: `npm run buil`

## Considerations
- I'm Ignored the bundle.js file on the dist folder

- UserEventCallbacks
- ComponentState
- NestedComponents
